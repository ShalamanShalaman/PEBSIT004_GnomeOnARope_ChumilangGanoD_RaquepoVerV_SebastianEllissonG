using UnityEngine;

public class SpinnerArm : MonoBehaviour
{
    public float speed = 90f; // degrees per second

    void Update()
    {
        transform.Rotate(0, 0, speed * Time.deltaTime);
    }
}

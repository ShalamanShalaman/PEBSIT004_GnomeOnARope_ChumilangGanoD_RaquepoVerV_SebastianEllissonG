﻿using UnityEngine;

public class Spike : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D other)
    {
        Gnome gnome = other.GetComponent<Gnome>();
        if (gnome != null)
        {
            GameManager gm = FindObjectOfType<GameManager>();

            // 👇 Skip everything if invincible
            if (gm != null && gm.gnomeInvincible)
            {
                Debug.Log("Gnome hit spike but is invincible!");
                return;
            }

            // Normal death sequence
            gnome.ShowDamageEffect(Gnome.DamageType.Slicing);
            gnome.DestroyGnome(Gnome.DamageType.Slicing);
            gm.ShowGameOver();
        }
    }
}
